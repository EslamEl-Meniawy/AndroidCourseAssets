package elmeniawy.eslam.demoproject;

/**
 * Created by Eslam El-Meniawy on 09-Apr-16.
 */
public class Utils {
    public static String SERVER_URL = "http://193.227.1.33/demo/libraries/fuapi.aspx?fn=ApplyMobileSearch";

    public static String KEY_SEARCH = "searchText1";
    
    public static String TAG_MAIN_ERROR = "ActivityMain-Search";

    public static String TAG_SEARCH = "searchRequest";
    public static int TIMEOUT = 60000;

    public static String KEY_RESULTS = "results";
    public static String KEY_IMAGE = "image";
    public static String KEY_TITLE = "title";
    public static String KEY_TYPE = "type";
    public static String KEY_PUBLISHER = "publisher";
}
