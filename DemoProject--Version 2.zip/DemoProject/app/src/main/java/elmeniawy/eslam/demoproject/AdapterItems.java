package elmeniawy.eslam.demoproject;

import android.content.Context;
import android.graphics.PorterDuff;
import android.support.v7.widget.ButtonBarLayout;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;

import java.util.ArrayList;

/**
 * Created by Eslam El-Meniawy on 09-Apr-16.
 */
public class AdapterItems extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static ArrayList<ItemResults> items = new ArrayList<>();
    private LayoutInflater inflater;
    private static Context context;
    private final int VIEW_ITEM = 1;

    public AdapterItems(Context context) {
        inflater = LayoutInflater.from(context);
        this.context = context;
    }

    public void setItems(ArrayList<ItemResults> items) {
        this.items = items;
        notifyItemRangeChanged(0, items.size());
    }

    @Override
    public int getItemViewType(int position) {
        return items.get(position) != null ? VIEW_ITEM : 0;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder;
        if (viewType == VIEW_ITEM) {
            View view = inflater.inflate(R.layout.item_results, parent, false);
            viewHolder = new ViewHolder(view);
        } else {
            View view = inflater.inflate(R.layout.item_load_more, parent, false);
            viewHolder = new ViewHolderButton(view);
        }
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof ViewHolder) {
            ItemResults currentItem = items.get(position);
            final ViewHolder holderItem = (ViewHolder) holder;
            holderItem.title.setText(currentItem.getTitle());
            holderItem.type.setText(currentItem.getType());
            holderItem.publisher.setText(currentItem.getPublisher());

            ImageLoader imageLoader = VolleySingleton.getInstance(context.getApplicationContext())
                    .getImageLoader();
            imageLoader.get(currentItem.getImage(), new ImageLoader.ImageListener() {
                @Override
                public void onResponse(ImageLoader.ImageContainer response, boolean isImmediate) {
                    holderItem.image.setImageBitmap(response.getBitmap());
                    holderItem.progressImage.setVisibility(View.GONE);
                }

                @Override
                public void onErrorResponse(VolleyError error) {
                    holderItem.image.setImageResource(R.mipmap.ic_launcher);
                    holderItem.progressImage.setVisibility(View.GONE);
                }
            });
        } else {
            ViewHolderButton holderItem = (ViewHolderButton) holder;
            holderItem.loadMore.setEnabled(true);
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder implements
            View.OnClickListener {
        ImageView image;
        TextView title, type, publisher;
        ProgressBar progressImage;

        public ViewHolder(View itemView) {
            super(itemView);
            image = (ImageView) itemView.findViewById(R.id.image);
            title = (TextView) itemView.findViewById(R.id.tv_title);
            type = (TextView) itemView.findViewById(R.id.tv_type);
            publisher = (TextView) itemView.findViewById(R.id.tv_publisher);
            progressImage = (ProgressBar) itemView.findViewById(R.id.progress_image);

            progressImage.getIndeterminateDrawable().setColorFilter(0xFFFF4081,
                    PorterDuff.Mode.SRC_IN);

            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            // open details
        }
    }

    static class ViewHolderButton extends RecyclerView.ViewHolder implements
            View.OnClickListener {
        Button loadMore;

        public ViewHolderButton(View itemView) {
            super(itemView);
            loadMore = (Button) itemView.findViewById(R.id.bt_load_more);

            loadMore.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            loadMore.setEnabled(false);
            ((ActivityMain)context).loadMore();
        }
    }
}
