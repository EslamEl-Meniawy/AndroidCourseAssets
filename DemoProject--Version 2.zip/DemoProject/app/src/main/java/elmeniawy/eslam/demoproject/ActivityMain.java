package elmeniawy.eslam.demoproject;

import android.content.SharedPreferences;
import android.graphics.PorterDuff;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.ShareActionProvider;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ActivityMain extends AppCompatActivity {
    private RelativeLayout layoutSearch;
    private ProgressBar progressLoading;
    private RecyclerView recyclerResults;
    private TextInputLayout layoutSearchText;
    private EditText etSearchText;
    private RequestQueue queue;
    private AdapterItems adapter;
    private SharedPreferences sharedPreferences;
    private String nextPage = "";
    private ArrayList<ItemResults> items;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        sharedPreferences = getSharedPreferences(Utils.PREF_NAME, MODE_PRIVATE);
        Utils.setLanguage(getResources(), sharedPreferences);

        setContentView(R.layout.activity_main);

        layoutSearch = (RelativeLayout) findViewById(R.id.layout_search);
        progressLoading = (ProgressBar) findViewById(R.id.progress_loading);
        recyclerResults = (RecyclerView) findViewById(R.id.recycler_results);
        layoutSearchText = (TextInputLayout) findViewById(R.id.layout_search_text);
        etSearchText = (EditText) findViewById(R.id.et_search_text);
        Button btSearch = (Button) findViewById(R.id.bt_search);

        progressLoading.getIndeterminateDrawable().setColorFilter(0xFFFF4081,
                PorterDuff.Mode.SRC_IN);

        queue = VolleySingleton.getInstance(ActivityMain.this.getApplicationContext())
                .getRequestQueue();

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(ActivityMain.this);
        recyclerResults.setLayoutManager(linearLayoutManager);

        adapter = new AdapterItems(ActivityMain.this);
        recyclerResults.setAdapter(adapter);

        etSearchText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                layoutSearchText.setError(null);
                layoutSearchText.setErrorEnabled(false);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        btSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        btSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (etSearchText.getText() == null ||
                        etSearchText.getText().toString().trim().equals("")) {
                    layoutSearchText.setErrorEnabled(true);
                    layoutSearchText.setError(getText(R.string.required));
                } else {
                    layoutSearch.setVisibility(View.GONE);
                    progressLoading.setVisibility(View.VISIBLE);
                    search(v);
                }
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_change_language) {
            String currentLang = sharedPreferences.getString(Utils.KEY_LANG, "en");
            SharedPreferences.Editor editor = sharedPreferences.edit();
            if (currentLang.equals("ar")) {
                editor.putString(Utils.KEY_LANG, "en");
            } else {
                editor.putString(Utils.KEY_LANG, "ar");
            }
            editor.apply();
            Utils.setLanguage(getResources(), sharedPreferences);
            ActivityMain.this.finish();
            startActivity(getIntent());
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void search(final View v) {
        nextPage = "";

        Map<String, String> params = new HashMap<>();
        params.put(Utils.KEY_SEARCH, etSearchText.getText().toString());

        VolleyCustomRequest request = new VolleyCustomRequest(Request.Method.POST, Utils.SERVER_URL,
                params, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                if (response != null && response.length() > 0) {
                    if (response.has(Utils.KEY_RESULTS) && !response.isNull(Utils.KEY_RESULTS)) {
                        try {
                            JSONArray news = response.getJSONArray(Utils.KEY_RESULTS);

                            items = new ArrayList<>();

                            for (int i = 0; i < news.length(); i++) {
                                JSONObject current = news.getJSONObject(i);

                                ItemResults item = new ItemResults();

                                item.setImage(current.getString(Utils.KEY_IMAGE));
                                item.setTitle(current.getString(Utils.KEY_TITLE));
                                item.setType(current.getString(Utils.KEY_TYPE));
                                item.setPublisher(current.getString(Utils.KEY_PUBLISHER));

                                items.add(item);
                            }

                            if (response.has(Utils.KEY_NEXT_PAGE) && !response.isNull(Utils.KEY_NEXT_PAGE)) {
                                if (!response.getString(Utils.KEY_NEXT_PAGE).equals("")) {
                                    nextPage = response.getString(Utils.KEY_NEXT_PAGE);
                                    items.add(null);
                                }
                            }

                            adapter.setItems(items);
                            recyclerResults.setVisibility(View.VISIBLE);
                        } catch (JSONException e) {
                            Log.e("ParseError", e.toString());
                        }
                    } else {
                        layoutSearch.setVisibility(View.VISIBLE);
                        Snackbar.make(v, getText(R.string.error), Snackbar.LENGTH_SHORT).show();
                    }
                } else {
                    layoutSearch.setVisibility(View.VISIBLE);
                    Snackbar.make(v, getText(R.string.error), Snackbar.LENGTH_SHORT).show();
                }
                progressLoading.setVisibility(View.GONE);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(Utils.TAG_MAIN_ERROR, error.toString());
                progressLoading.setVisibility(View.GONE);
                layoutSearch.setVisibility(View.VISIBLE);
                Snackbar.make(v, getText(R.string.error), Snackbar.LENGTH_SHORT).show();
            }
        });

        RetryPolicy policy = new DefaultRetryPolicy(Utils.TIMEOUT,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        request.setRetryPolicy(policy);
        request.setTag(Utils.TAG_SEARCH);
        queue.add(request);
    }

    public void loadMore() {
        if (!nextPage.equals("")) {
            JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, nextPage, null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            items.remove(items.size() - 1);
                            adapter.notifyItemRemoved(items.size());

                            if (response != null && response.length() > 0) {
                                if (response.has(Utils.KEY_RESULTS) && !response.isNull(Utils.KEY_RESULTS)) {
                                    try {
                                        JSONArray news = response.getJSONArray(Utils.KEY_RESULTS);

                                        for (int i = 0; i < news.length(); i++) {
                                            JSONObject current = news.getJSONObject(i);

                                            ItemResults item = new ItemResults();

                                            item.setImage(current.getString(Utils.KEY_IMAGE));
                                            item.setTitle(current.getString(Utils.KEY_TITLE));
                                            item.setType(current.getString(Utils.KEY_TYPE));
                                            item.setPublisher(current.getString(Utils.KEY_PUBLISHER));

                                            items.add(item);
                                        }

                                        if (response.has(Utils.KEY_NEXT_PAGE) && !response.isNull(Utils.KEY_NEXT_PAGE)) {
                                            if (!response.getString(Utils.KEY_NEXT_PAGE).equals("")) {
                                                nextPage = response.getString(Utils.KEY_NEXT_PAGE);
                                                items.add(null);
                                            }
                                        }

                                        adapter.setItems(items);
                                        recyclerResults.setVisibility(View.VISIBLE);
                                    } catch (JSONException e) {
                                        Log.e("ParseError", e.toString());
                                    }
                                } else {
                                    Snackbar.make(findViewById(R.id.recycler_results), getText(R.string.error), Snackbar.LENGTH_SHORT).show();
                                    items.remove(items.size() - 1);
                                    adapter.notifyItemRemoved(items.size());
                                    items.add(null);
                                    adapter.notifyItemInserted(items.size());
                                }
                            } else {
                                Snackbar.make(findViewById(R.id.recycler_results), getText(R.string.error), Snackbar.LENGTH_SHORT).show();
                                items.remove(items.size() - 1);
                                adapter.notifyItemRemoved(items.size());
                                items.add(null);
                                adapter.notifyItemInserted(items.size());
                            }
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Snackbar.make(findViewById(R.id.recycler_results), getText(R.string.error), Snackbar.LENGTH_SHORT).show();
                            items.remove(items.size() - 1);
                            adapter.notifyItemRemoved(items.size());
                            items.add(null);
                            adapter.notifyItemInserted(items.size());
                        }
                    });

            RetryPolicy policy = new DefaultRetryPolicy(Utils.TIMEOUT,
                    DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
            request.setRetryPolicy(policy);
            request.setTag(Utils.TAG_SEARCH);
            queue.add(request);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (queue != null) {
            queue.cancelAll(Utils.TAG_SEARCH);
        }
    }
}
