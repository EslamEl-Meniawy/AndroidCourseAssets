package elmeniawy.eslam.demoproject;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by Eslam El-Meniawy on 09-Apr-16.
 */
public class ItemResults implements Parcelable {
    private String image, title, type, publisher;

    public ItemResults() {
    }

    protected ItemResults(Parcel in) {
        image = in.readString();
        title = in.readString();
        type = in.readString();
        publisher = in.readString();
    }

    public static final Creator<ItemResults> CREATOR = new Creator<ItemResults>() {
        @Override
        public ItemResults createFromParcel(Parcel in) {
            return new ItemResults(in);
        }

        @Override
        public ItemResults[] newArray(int size) {
            return new ItemResults[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(image);
        dest.writeString(title);
        dest.writeString(type);
        dest.writeString(publisher);
    }

    public String getImage() {
        return image;
    }

    public String getTitle() {
        return title;
    }

    public String getType() {
        return type;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }
}
