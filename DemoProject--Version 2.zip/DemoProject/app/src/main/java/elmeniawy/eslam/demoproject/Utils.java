package elmeniawy.eslam.demoproject;

import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;

import java.util.Locale;

/**
 * Created by Eslam El-Meniawy on 09-Apr-16.
 */
public class Utils {
    public static String SERVER_URL = "http://193.227.1.33/demo/libraries/fuapi.aspx?fn=ApplyMobileSearch";

    public static String KEY_SEARCH = "searchText1";
    
    public static String TAG_MAIN_ERROR = "ActivityMain-Search";

    public static String TAG_SEARCH = "searchRequest";
    public static int TIMEOUT = 60000;

    public static String KEY_RESULTS = "results";
    public static String KEY_IMAGE = "image";
    public static String KEY_TITLE = "title";
    public static String KEY_TYPE = "type";
    public static String KEY_PUBLISHER = "publisher";
    public static String KEY_NEXT_PAGE = "Link4NextPage";

    public static String KEY_LANG = "lang";
    public static String PREF_NAME = "mySharedPreferences";

    public static void setLanguage(Resources res, SharedPreferences sharedPreferences) {
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        conf.locale = new Locale(sharedPreferences.getString(KEY_LANG, "en"));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            conf.setLayoutDirection(conf.locale);
        }
        res.updateConfiguration(conf, dm);
    }
}
