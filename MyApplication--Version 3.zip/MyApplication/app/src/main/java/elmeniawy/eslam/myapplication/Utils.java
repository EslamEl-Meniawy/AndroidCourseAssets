package elmeniawy.eslam.myapplication;

import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.util.DisplayMetrics;

import java.util.Locale;

/**
 * Created by Eslam El-Meniawy on 02-Apr-16.
 */
public class Utils {
    public static final String PREF_NAME = "mSharedPrefrences";
    public static final String KEY_LANG = "lang";
    public static final String KEY_NAME = "name";
    public static final String KEY_EMAIL = "email";
    public static final String KEY_PHONE = "phone";
    public static final String KEY_MESSAGE = "message";

    public static void changeLang(SharedPreferences sharedPreferences,
                                  Resources res, int position) {
        String lang;
        if (position == 0) {
            lang = "ar";
        } else {
            lang = "en";
        }
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        if (!conf.locale.getLanguage().equals(lang)) {

            conf.locale = new Locale(lang);
            res.updateConfiguration(conf, dm);
        }
    }
}
