package elmeniawy.eslam.myapplication;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by Eslam El-Meniawy on 02-Apr-16.
 */
public class Fragment1 extends Fragment {
    RequestQueue queue;
    public Fragment1() {
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_1, container, false);

        RecyclerView recyclerView = (RecyclerView) rootView.findViewById(R.id.recycler);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(linearLayoutManager);

        final ItemsAdapter adapter = new ItemsAdapter(getActivity());
        recyclerView.setAdapter(adapter);

        /*ArrayList<Item> items = new ArrayList<>();
        for (int i = 0; i < 20; i++) {
            Item item = new Item();
            item.setId(i);
            item.setTitle("Item " + (i + 1));
            item.setImage(R.drawable.ic_android_black_36dp);
            items.add(item);
        }

        adapter.setItems(items);*/

        queue = VolleySingleton.getInstance(getActivity().getApplicationContext())
                .getRequestQueue();


        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET,
                "http://193.227.1.33/eulc_v5/libraries/fuapi.aspx?ScopeID=1.&fn=MobileNews",
                null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                if (response != null && response.length() > 0) {
                    if (response.has("news") && !response.isNull("news")) {
                        try {
                            JSONArray news = response.getJSONArray("news");

                            ArrayList<Item> items = new ArrayList<>();

                            for (int i = 0; i < news.length(); i++) {
                                JSONObject current = news.getJSONObject(i);

                                Item item = new Item();

                                item.setId(current.getInt("id"));
                                item.setTitle(current.getString("title"));

                                items.add(item);
                            }

                            adapter.setItems(items);
                        } catch (JSONException e) {
                            Log.e("ParseError", e.toString());
                        }
                    }
                }
                //tv.setText(response.toString());
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_LONG).show();
            }
        });

        int timeout = 60000;
        RetryPolicy policy = new DefaultRetryPolicy(timeout,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        request.setRetryPolicy(policy);
        request.setTag("news");
        queue.add(request);

        return rootView;
    }
}
