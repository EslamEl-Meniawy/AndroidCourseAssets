package elmeniawy.eslam.myapplication;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Eslam El-Meniawy on 02-Apr-16.
 */
public class ItemsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static ArrayList<Item> items = new ArrayList<>();
    private LayoutInflater inflater;
    private static Context context;

    public ItemsAdapter(Context context) {
        inflater = LayoutInflater.from(context);
        this.context = context;
    }

    public void setItems(ArrayList<Item> items) {
        this.items = items;
        notifyItemRangeChanged(0, items.size());
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder;
        View view = inflater.inflate(R.layout.item, parent, false);
        viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        Item currentItem = items.get(position);
        ViewHolder holderItem = (ViewHolder) holder;
        holderItem.title.setText(currentItem.getTitle());
        holderItem.imageView.setImageResource(currentItem.getImage());
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder implements
            View.OnClickListener {
        TextView title;
        ImageView imageView;

        public ViewHolder(View itemView) {
            super(itemView);
            title = (TextView) itemView.findViewById(R.id.title);
            imageView = (ImageView) itemView.findViewById(R.id.image);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            Item currentItem = items.get(getLayoutPosition());

            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle(currentItem.getTitle())
                    .setMessage(String.valueOf(currentItem.getId()))
            .setCancelable(false)
            .setNeutralButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            });
            builder.create().show();
        }
    }
}
