package elmeniawy.eslam.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class Main2Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            TextView tv = (TextView) findViewById(R.id.text_view);
            tv.setText("Dear " + bundle.getString(Utils.KEY_NAME) + ",\n"
            + "We received your message \"" + bundle.getString(Utils.KEY_MESSAGE) +
            "\" and we will contact you at " + bundle.getString(Utils.KEY_EMAIL) +
            " or " + bundle.getString(Utils.KEY_PHONE) + ".\n Thanks for your time");
        }
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        goBack();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.details, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            goBack();
            return true;
        } else if (item.getItemId() == R.id.settings) {
            Toast.makeText(Main2Activity.this, "Settings pressed", Toast.LENGTH_SHORT).show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void goBack() {
        Intent intent = new Intent(Main2Activity.this, MainActivity.class);
        startActivity(intent);
        Main2Activity.this.finish();
    }
}
