package elmeniawy.eslam.myapplication;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by Eslam El-Meniawy on 02-Apr-16.
 */
public class Fragment2 extends Fragment {
    RequestQueue queue;

    public Fragment2() {
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_2, container, false);

        final TextView tv = (TextView) rootView.findViewById(R.id.text);
        final ProgressBar loading = (ProgressBar) rootView.findViewById(R.id.loading);

        queue = VolleySingleton.getInstance(getActivity().getApplicationContext())
                .getRequestQueue();


        loading.setVisibility(View.VISIBLE);
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET,
                "http://193.227.1.33/eulc_v5/libraries/fuapi.aspx?ScopeID=1.&fn=MobileNews",
                null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                loading.setVisibility(View.GONE);
                if (response != null && response.length() > 0) {
                    if (response.has("news") && !response.isNull("news")) {
                        try {
                            JSONArray news = response.getJSONArray("news");
                            tv.setText("News:");
                            for (int i = 0; i < news.length(); i++) {
                                JSONObject current = news.getJSONObject(i);

                                tv.append("\n" + current.getString("title"));
                            }
                        } catch (JSONException e) {
                            Log.e("ParseError", e.toString());
                        }
                    }
                }
                //tv.setText(response.toString());
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                loading.setVisibility(View.GONE);
                Toast.makeText(getActivity(), error.toString(), Toast.LENGTH_LONG).show();
            }
        });

        int timeout = 60000;
        RetryPolicy policy = new DefaultRetryPolicy(timeout,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);
        request.setRetryPolicy(policy);
        request.setTag("news");
        queue.add(request);

        return rootView;
    }

    @Override
    public void onStop() {
        super.onStop();
        if (queue != null) {
            queue.cancelAll("news");
        }
    }
}
