package elmeniawy.eslam.myapplication;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    private EditText name, email, phone, message;
    SharedPreferences sp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        sp = MainActivity.this.getSharedPreferences("mSharedPrefrences", MODE_PRIVATE);
        //Utils.changeLang(sp, getResources(), sp.getInt(Utils.KEY_LANG, 1));

        setContentView(R.layout.activity_main);

        Button bt = (Button) findViewById(R.id.button_print);
        name = (EditText) findViewById(R.id.name);
        email = (EditText) findViewById(R.id.email);
        phone = (EditText) findViewById(R.id.phone);
        message = (EditText) findViewById(R.id.message);

        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextInputLayout emailLayout =
                        (TextInputLayout) findViewById(R.id.emailLayout);
                TextInputLayout phoneLayout =
                        (TextInputLayout) findViewById(R.id.phoneLayout);
                if ((name.getText() == null ||
                        name.getText().toString().trim().equals("")) &&
                        (email.getText() == null ||
                                email.getText().toString().trim().equals("")) &&
                        (phone.getText() == null ||
                                phone.getText().toString().trim().equals("")) &&
                        (message.getText() == null ||
                                message.getText().toString().trim().equals(""))) {
                    Snackbar.make(v, "Enter all fields", Snackbar.LENGTH_SHORT).show();
                } else {
                    if (!Patterns.EMAIL_ADDRESS.matcher(email.getText().toString())
                            .matches()) {
                        emailLayout.setError("Invalid email");
                    } else if (!Pattern.matches("^[+]?[0-9]{10,13}$",
                            phone.getText().toString())) {
                        phoneLayout.setError("Invalid phone");
                    } else {
                        emailLayout.setErrorEnabled(false);
                        phoneLayout.setErrorEnabled(false);
                        Intent intent = new Intent(MainActivity.this, Main2Activity.class);
                        intent.putExtra(Utils.KEY_NAME, name.getText().toString());
                        intent.putExtra(Utils.KEY_EMAIL, email.getText().toString());
                        intent.putExtra(Utils.KEY_PHONE, phone.getText().toString());
                        intent.putExtra(Utils.KEY_MESSAGE, message.getText().toString());
                        startActivity(intent);
                        MainActivity.this.finish();
                    }
                }
            }
        });

        name.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {

            }
        });
    }

    @Override
    protected void onPause() {
        //saveState();
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        //restoreState();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.settings) {
            startActivity(new Intent(MainActivity.this, ActivitySettings.class));
            return true;
        } else if (item.getItemId() == R.id.open_drawer) {
            startActivity(new Intent(MainActivity.this, ActivityDrawer.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void saveState() {
        SharedPreferences.Editor editor = sp.edit();
        //editor.putString("et", et.getText().toString());
        editor.apply();
    }

    private void restoreState() {
        //et.setText(sp.getString("et", "Default"));
    }
}
