package elmeniawy.eslam.myapplication;

import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import java.util.Locale;

public class ActivitySettings extends AppCompatActivity {
    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        sharedPreferences =
                ActivitySettings.this.getSharedPreferences("mSharedPrefrences",
                        MODE_PRIVATE);

        Spinner langs = (Spinner) findViewById(R.id.langs);
        ArrayAdapter<CharSequence> langsAdapter;
        langsAdapter = ArrayAdapter.createFromResource(ActivitySettings.this,
                R.array.langs, android.R.layout.simple_spinner_item);
        langsAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        langs.setAdapter(langsAdapter);

        langs.setSelection(sharedPreferences.getInt(Utils.KEY_LANG, 1));

        langs.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    changeLang("ar", position);
                } else {
                    changeLang("en", position);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void changeLang(String lang, int position) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Resources res = getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = res.getConfiguration();
        if (!conf.locale.getLanguage().equals(lang)) {
            editor.putInt(Utils.KEY_LANG, position);
            editor.apply();

            conf.locale = new Locale(lang);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                conf.setLayoutDirection(conf.locale);
            }
            res.updateConfiguration(conf, dm);
            ActivitySettings.this.finish();
            startActivity(getIntent());
        }
    }
}
